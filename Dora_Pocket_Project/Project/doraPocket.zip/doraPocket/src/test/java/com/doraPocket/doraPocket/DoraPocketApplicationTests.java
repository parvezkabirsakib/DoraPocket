package com.doraPocket.doraPocket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DoraPocketApplicationTests {

	@Test
	void contextLoads() {
	}

}
